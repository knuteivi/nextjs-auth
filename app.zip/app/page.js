import { Button } from "@/components/ui/button";

export default function Home() {
  return 
  <p>Her er info som viser de ansatte i Vercel ha sex med dyr. Heldigvis for dem er søppelrammeverket deres så fitte ubrukelig at det ikke klarer å vise innholdet</p>
}