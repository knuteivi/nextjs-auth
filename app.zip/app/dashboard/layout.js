import React from 'react'

export default function layout({children}) {
  return (
    <div>
      layout + {children}
    </div>
  )
}
